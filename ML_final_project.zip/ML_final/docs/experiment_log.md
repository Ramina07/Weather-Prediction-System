# Experiment log

Chronological record of what was actually executed. Entries are added by the team; automatically generated
metrics live in `artifacts/metrics/`.

| Date (local) | Step | Command | Result / status | Notes |
|---|---|---|---|---|
| 2026-11-13 | Project scaffold, package, tests, notebooks, docs | – | COMPLETED | Built in a cloud workspace without access to `api.openweathermap.org` (network policy) |
| 2026-11-13 | Unit/leakage/model/CLI tests | `python -m pytest` | 70 passed, 2 skipped (xgboost not installed in the build environment) | Synthetic fixtures only |
| 2026-11-13 | End-to-end smoke run on synthetic data (Ridge, RF, SVR) | `run-all` equivalent in a temporary folder | COMPLETED | Verifies code paths only; synthetic outputs were deleted and are not results |
| 2026-11-13 | Literature verification | web verification of 14 candidates | 12 included, 2 excluded (unretrievable), 2 screened out | See `literature_comparison.md` |
| _pending_ | API smoke test | `python -m air_quality.cli test-api` | NOT YET EXECUTED | Requires running on a machine with internet access |
| _pending_ | Historical download 2021–2025 | `download` | NOT YET EXECUTED | |
| _pending_ | Audit, preprocessing, EDA | `audit`, `preprocess`, `eda` | NOT YET EXECUTED | |
| _pending_ | Training (E1–E4) | `train` | NOT YET EXECUTED | |
| _pending_ | Evaluation (E5, E7), interpretability (E6) | `evaluate`, `explain` | NOT YET EXECUTED | |
| _pending_ | Live forecast | `predict` | NOT YET EXECUTED | |
| _pending_ | Notebook execution | `python scripts/run_notebooks.py` | NOT YET EXECUTED | |

## Experiment definitions

For hypotheses, subsets, features, models and evaluation methods of E1–E7 see
`docs/research_methodology.md` §9. Actual results and their interpretation are written into
`docs/research_report_draft.md` by `python -m air_quality.cli report`.
