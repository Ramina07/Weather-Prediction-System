# References (APA 7th edition)

18 references: 12 experimental studies (2022–2026) + 6 official/methodological sources. Metadata verified on
13 November 2026. BibTeX: `docs/references.bib`.

Abuouelezz, W., Ali, N., Aung, Z., Altunaiji, A., Shah, S. B., & Gliddon, D. (2025). Exploring PM2.5 and PM10 ML forecasting models: A comparative study in the UAE. *Scientific Reports, 15*, 9797. https://doi.org/10.1038/s41598-025-94013-1

Agibayeva, A., Khalikhan, R., Guney, M., Karaca, F., Torezhan, A., & Avcu, E. (2022). An air quality modeling and disability-adjusted life years (DALY) risk assessment case study: Comparing statistical and machine learning approaches for PM2.5 forecasting. *Sustainability, 14*(24), 16641. https://doi.org/10.3390/su142416641

Bhatta, J., Acharya, S. R., & Yang, K. M. (2026). Machine learning-enhanced air quality forecasting and trend analysis: A five-year comprehensive assessment of PM2.5 concentrations in Bangkok, Thailand. *Environmental Challenges, 22*, 101442. https://doi.org/10.1016/j.envc.2026.101442

Breiman, L. (2001). Random forests. *Machine Learning, 45*(1), 5–32. https://doi.org/10.1023/A:1010933404324

Chen, T., & Guestrin, C. (2016). XGBoost: A scalable tree boosting system. In *Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining* (pp. 785–794). https://doi.org/10.1145/2939672.2939785

Chivukula, S., Cortes Santos, A. J., Delgado, R., Arachchige, D. K., Caraballo-Vega, J. A., & Friberg, M. D. (2026). An applied assessment of multi-source data fusion by machine learning for PM2.5 daily concentration prediction. *Atmosphere, 17*(8), 779. https://doi.org/10.3390/atmos17080779

Fetahi, E., Ovuoraye, P., Canhasi, E., Susuri, A., & Misini, A. (2025). Multi-horizon air pollution prediction using interpretable machine learning techniques in a growing urban area. *Ecological Engineering & Environmental Technology, 26*(8), 97–114. https://doi.org/10.12912/27197050/207283

Haseeb, M., Tahir, Z., Mehmood, S. A., Arif, H., Kousar, S., Ghafoor, S., & Mehmood, K. (2026). Ensemble artificial intelligence fusing satellite, reanalysis, and ground observations for improved PM2.5 prediction. *Atmosphere, 17*(4), 411. https://doi.org/10.3390/atmos17040411

Hoerl, A. E., & Kennard, R. W. (1970). Ridge regression: Biased estimation for nonorthogonal problems. *Technometrics, 12*(1), 55–67. https://doi.org/10.1080/00401706.1970.10488634

Hyso, A., & Gjylapi, D. (2026). Benchmark-driven model selection for forecasting over open gridded urban air-quality fields. *Baltic Journal of Modern Computing, 14*(3), 618–644. https://doi.org/10.22364/bjmc.2026.14.3.06

Jalali, M. W., Saidi, B., Farahmand, H., Rezvan Panah, M. A., & Saruhan, E. N. (2025). Scalable AI-driven air quality forecasting and classification for public health applications. *Discover Atmosphere, 3*, 25. https://doi.org/10.1007/s44292-025-00052-8

Makhdoomi, A., Sarkhosh, M., & Ziaei, S. (2025). PM2.5 concentration prediction using machine learning algorithms: An approach to virtual monitoring stations. *Scientific Reports, 15*, 8076. https://doi.org/10.1038/s41598-025-92019-3

Nguyen, P. H., Dao, N. K., & Nguyen, L. S. P. (2024). Development of machine learning and deep learning prediction models for PM2.5 in Ho Chi Minh City, Vietnam. *Atmosphere, 15*(10), 1163. https://doi.org/10.3390/atmos15101163

OpenWeather. (n.d.). *Air pollution API*. Retrieved November 13, 2026, from https://openweathermap.org/api/air-pollution

Psomadakis, I., Christakis, C., Metallidou, C. L., Panagiotakopoulos, T., Katsafadou, A. I., & Kiouvrekis, Y. (2026). Forecasting of PM2.5/PM10 using machine learning: A benchmarking study based on open air quality IoT datasets. *Electronics, 15*(19), 4496. https://doi.org/10.3390/electronics15194496

Sapakova, S., Sapakov, A., Auyelbekov, O., Tukenova, L., Tynymbayev, S., Ualiyev, Z., Skakova, A., & Kabdoldina, A. (2026). A web-based digital twin for traffic and air quality monitoring: A prototype study in Almaty, Kazakhstan. *Technologies, 14*(8), 512. https://doi.org/10.3390/technologies14080512

Smola, A. J., & Schölkopf, B. (2004). A tutorial on support vector regression. *Statistics and Computing, 14*(3), 199–222. https://doi.org/10.1023/B:STCO.0000035301.49549.88

World Health Organization. (2021). *WHO global air quality guidelines: Particulate matter (PM2.5 and PM10), ozone, nitrogen dioxide, sulfur dioxide and carbon monoxide*. World Health Organization.
