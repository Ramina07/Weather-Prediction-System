# 2. Literature Review

This review synthesizes twelve experimental studies published between 2022 and 2026 that were individually
verified against their publisher pages or indexed records on 13 November 2026 (see
`docs/literature_comparison.csv` for the 40-field extraction and `docs/literature_comparison.md` for the
readable matrix). Where a study's numerical result could not be read in the accessible text, it is reported as
unavailable rather than estimated. Two seed candidates could not be retrieved and are therefore not cited
(the exclusion log is at the end of `literature_comparison.md`).

The twelve studies fall into three groups that matter for how their results can be compared with ours:

* **Genuine future forecasting of PM2.5** with past-only inputs: Sapakova et al. (2026), Fetahi et al. (2025),
  Psomadakis et al. (2026), Chivukula et al. (2026), Hyso and Gjylapi (2026), Abuouelezz et al. (2025) and
  Bhatta et al. (2026).
* **Concurrent estimation**: PM2.5 is predicted from inputs that are measured at the same time (co-pollutants,
  meteorology, satellite retrievals), with no lead time: Agibayeva et al. (2022), Haseeb et al. (2026),
  Nguyen et al. (2024) and Makhdoomi et al. (2025).
* **Mixed classification/regression systems**: Jalali et al. (2025).

## 2.1. Air pollution and PM2.5 forecasting

Fine particulate matter (PM2.5) is the pollutant most closely tied to the health burden of urban air
pollution. The World Health Organization (2021) lowered its 24-hour guideline level for PM2.5 to 15 µg/m³,
which makes day-level concentration forecasts directly relevant to public advice. In Kazakhstan, Agibayeva
et al. (2022) estimated that PM2.5 exposure in Astana in 2019 corresponded to between roughly 2,200 and 7,500
disability-adjusted life years, depending on the monitoring station, and they found a sharp contrast between
the heating (October–April) and non-heating periods. These two observations — a health-relevant daily
threshold and strong seasonality linked to heating — define the practical setting of the present project.

Forecasting PM2.5 is difficult for three reasons that recur across the reviewed studies. First,
concentrations are strongly autocorrelated, so naive forecasts that repeat recent values are already accurate
at short horizons (Sapakova et al., 2026; Hyso & Gjylapi, 2026). Second, accuracy degrades rapidly as the
horizon grows: XGBoost in Prishtina explained about 86% of variance one hour ahead but only about half of it
24 hours ahead (Fetahi et al., 2025), and in Bangkok performance was judged adequate for one to seven days but
deteriorated beyond two weeks (Bhatta et al., 2026). Third, high-pollution episodes are rare and are the
hardest to predict; random forests were reported to under-estimate extremes in Lahore (Haseeb et al., 2026)
and to over-estimate high concentrations in Astana (Agibayeva et al., 2022).

## 2.2. Traditional regression methods

Linear models remain the reference point in almost every study. They are cheap, transparent and, when
predictors are strongly correlated with the target, surprisingly competitive. In Astana, multiple linear
regression reached R² values between 0.68 and 0.99 depending on season and station, although random forest
was better on every reported criterion (Agibayeva et al., 2022). Pooled Ridge regression was one of the
enhanced models in the Albanian day-ahead benchmark, where differences between models were often small
(Hyso & Gjylapi, 2026), and linear regression served as a baseline in Prishtina (Fetahi et al., 2025),
Almaty (Sapakova et al., 2026) and the U.S. multi-city study (Chivukula et al., 2026).

The main limitation of linear models is their inability to represent interactions — for example, the fact that
a given recent concentration implies a different tomorrow during the heating season than in summer. Ridge
regression (Hoerl & Kennard, 1970) adds an L2 penalty that stabilizes coefficients when many lagged and rolling
features are collinear, which is exactly the situation created by our feature design. We therefore use Ridge,
not ordinary least squares, as the interpretable linear model.

## 2.3. Tree-based ensemble models

Tree ensembles are the most frequently reported strong performers. Random Forest (Breiman, 2001) was best in
Astana (Agibayeva et al., 2022) and was the strongest single model in Lahore (Haseeb et al., 2026). Gradient
boosting variants led in Prishtina (XGBoost; Fetahi et al., 2025), in Bangkok (Gradient Boosting; Bhatta et al.,
2026), in Dallas for next-day prediction (XGBoost, R² = 0.667 on a 2023 hold-out; Chivukula et al., 2026) and,
with HistGradientBoosting, in the Albanian benchmark (Hyso & Gjylapi, 2026). LightGBM and CatBoost appear in
several studies but rarely change the conclusion (Haseeb et al., 2026; Makhdoomi et al., 2025).

Two lessons are important. First, the advantage of tree ensembles over simpler models shrinks at day-ahead
horizons: in Albania the 1-day PM2.5 MAE of the best enhanced model was 1.92 µg/m³ against 2.04 µg/m³ for the
best baseline, and none of the improvements remained clearly significant after multiple-comparison
correction (Hyso & Gjylapi, 2026). Second, the highest published scores come from concurrent-estimation
designs: Makhdoomi et al. (2025) report R² ≈ 0.98 for gradient boosting, but with same-time inputs and a random
split. We select **Random Forest** (bagging, robust to noisy features, provides importance estimates) and
**XGBoost** (regularized boosting; Chen & Guestrin, 2016) because they represent the two dominant ensemble
families in the literature and are both practical on a laptop.

## 2.4. Support vector regression

Kernel methods offer a different inductive bias: smooth non-linear functions controlled by a margin and a
kernel bandwidth. In the Greek next-day benchmark, an RBF-kernel support vector machine was the most
consistent winner across stations and pollutants (Psomadakis et al., 2026); in Abu Dhabi, linear SVR was
generally the best PM2.5 model one and two hours ahead (MAE 6.630 µg/m³ at 1 h; Abuouelezz et al., 2025). SVR
was also among the compared models in Prishtina and Ho Chi Minh City (Fetahi et al., 2025; Nguyen et al., 2024).
SVR is sensitive to feature scaling and its cost grows with the number of samples, which is manageable for our
daily dataset of roughly 1,800 issue dates. Its ε-insensitive loss (Smola & Schölkopf, 2004) also ignores small
residuals, which can be advantageous when the target is noisy. We include an RBF-kernel SVR, always preceded by
standardization fitted on training data only.

## 2.5. Time-series forecasting methods

Across the forecasting studies, past values of the target dominate. Lags and rolling statistics of PM2.5 were
the core inputs in Greece (lags 1–28 days, trailing 3/7/14-day means and standard deviations; Psomadakis et al.,
2026), Albania (lags and rolling windows ending at t-1; Hyso & Gjylapi, 2026), the United States (1-day lag,
7-day mean and standard deviation; Chivukula et al., 2026) and Almaty (short lags and rolling means; Sapakova
et al., 2026). Feature-importance analyses agree: in Bangkok the 3-day moving average alone accounted for 42%
and 60% of importance in Random Forest and Gradient Boosting (Bhatta et al., 2026), and in Almaty the current
PM2.5 value and its short rolling mean together accounted for over 95% of Random Forest importance (Sapakova
et al., 2026). Cyclical (sine/cosine) calendar encodings were used in most of these studies.

The evaluation protocol is as important as the features. The more rigorous studies fix chronological
boundaries before any processing (Psomadakis et al., 2026), hold out whole years (Chivukula et al., 2026;
Haseeb et al., 2026; Abuouelezz et al., 2025) or use rolling-origin backtesting (Hyso & Gjylapi, 2026). Only
some studies include a **persistence** benchmark, and where it is included it is informative: in Almaty
nowcasting, persistence outperformed all ML models (R² 0.980 versus at most 0.977 at 15 minutes; Sapakova
et al., 2026), and in Greece SARIMA fell below persistence at several stations (Psomadakis et al., 2026). A
day-ahead daily-mean target sits between these extremes: persistence remains strong because of day-to-day
autocorrelation, but there is room for models that learn seasonal and regime-dependent adjustments.

## 2.6. Data sources and dataset limitations

| Data type | Studies | Strength | Limitation for comparison |
|---|---|---|---|
| OpenWeather API data | Sapakova et al. (2026); Jalali et al. (2025, meteorology only) | Global, free, consistent schema, programmatic access | Modelled/aggregated values for a coordinate; production method not documented on the API page (OpenWeather, n.d.); no station-level validation in our project |
| Ground monitoring stations | Agibayeva et al. (2022); Abuouelezz et al. (2025); Psomadakis et al. (2026); Nguyen et al. (2024); Makhdoomi et al. (2025); Bhatta et al. (2026) | Direct measurements, regulatory quality | Point representativeness; gaps; access restrictions |
| Satellite / reanalysis | Haseeb et al. (2026); Chivukula et al. (2026) | Spatial coverage | Coarse or monthly resolution; usually concurrent estimation |
| Open gridded model fields | Hyso & Gjylapi (2026) | Reproducible, multi-city | Model output, not observations |
| Multi-source fusion / multi-city | Chivukula et al. (2026); Jalali et al. (2025) | Larger samples | Heterogeneous test populations; cross-city metrics not comparable |

Because the targets differ (station measurements, satellite-derived estimates, modelled API fields), the
temporal resolution differs (15 minutes to monthly) and the horizon differs (none to several days), the
published metrics are **not directly comparable** with each other or with ours. An R² of 0.98 for concurrent
estimation from co-pollutants (Makhdoomi et al., 2025) and an R² of 0.50 for 24-hour-ahead hourly forecasting
(Fetahi et al., 2025) answer different questions. Classification accuracy (99.96% for AQI classes; Jalali et
al., 2025) measures yet another task and is not a regression metric.

## 2.7. Comparative analysis of existing studies

Read together, the studies show a consistent pattern rather than a single best algorithm. When the evaluation
is strict — past-only inputs, chronological testing, explicit baselines — reported improvements over simple
references are moderate: small and not clearly significant in Albania (Hyso & Gjylapi, 2026), absent at very
short horizons in Almaty (Sapakova et al., 2026), and model-dependent and station-dependent in Greece
(Psomadakis et al., 2026). When the evaluation uses concurrent predictors or random splits, reported scores
are very high (Makhdoomi et al., 2025; Agibayeva et al., 2022) but say little about forecasting ability.
Within the forecasting group, tree ensembles (Fetahi et al., 2025; Chivukula et al., 2026; Bhatta et al., 2026)
and SVR (Psomadakis et al., 2026; Abuouelezz et al., 2025) win in different settings, which supports comparing
both families on the same data rather than assuming a winner. Deep learning did not dominate where it was
tested against trees on daily data (Chivukula et al., 2026), and several authors explicitly avoided it for
small datasets (Sapakova et al., 2026).

Reporting practices also vary. Some studies report only R² (Psomadakis et al., 2026), others only MAE/MAPE
(Hyso & Gjylapi, 2026) or RMSE/IOA (Nguyen et al., 2024). Very few report skill relative to persistence. This
heterogeneity is one reason why we report MAE, RMSE, R², sMAPE, bias and persistence skill together.

## 2.8. Strengths and limitations of the literature

* **Short-horizon success does not transfer to the next day.** Accuracy at 15 minutes or 1 hour (Sapakova et
  al., 2026; Fetahi et al., 2025; Abuouelezz et al., 2025) overstates what is achievable for a day-ahead mean.
* **Data leakage risks.** Concurrent co-pollutants or AQI as inputs (Makhdoomi et al., 2025), interpolation
  over the full record (Chivukula et al., 2026) and ensemble weights possibly tuned on test data (Haseeb et
  al., 2026) can inflate results.
* **Random versus chronological splitting.** Random 80/20 splits (Agibayeva et al., 2022; Nguyen et al., 2024;
  Makhdoomi et al., 2025) allow temporally adjacent days to appear in both training and testing.
* **Limited geographical transferability.** Results are for single cities or stations; Central Asian evidence
  is limited to Almaty nowcasting (Sapakova et al., 2026) and Astana estimation (Agibayeva et al., 2022).
* **Missing data.** Treatments range from listwise deletion (Makhdoomi et al., 2025) to climatological
  interpolation (Abuouelezz et al., 2025); few studies state completeness thresholds for daily targets
  (Chivukula et al., 2026 is an exception).
* **Unclear horizons.** Several papers use "forecasting" in the title without a lead time (Agibayeva et al.,
  2022; Nguyen et al., 2024; Makhdoomi et al., 2025; Haseeb et al., 2026).
* **Lack of baselines.** Persistence is absent from most estimation studies.
* **Source-data uncertainty.** Modelled products (OpenWeather, n.d.; Hyso & Gjylapi, 2026) are not station
  measurements and were not validated against stations in those studies.

## 2.9. Research gap

PM2.5 prediction has been studied with many machine learning techniques, but the reported results vary
widely across datasets, horizons and evaluation protocols, and the strongest headline numbers often come
from concurrent-estimation designs. For Kazakhstan, the verified studies we found address either concurrent
estimation in Astana with station data (Agibayeva et al., 2022) or very short-horizon nowcasting in Almaty
using OpenWeather data (Sapakova et al., 2026). We did not find a study that evaluates a **day-ahead daily-mean**
PM2.5 forecast for Astana using multi-year OpenWeather historical pollution data with leakage-free issue-time
features, chronological train/validation/test years and an explicit persistence baseline. This project
addresses that specific gap. We do not claim that no similar work exists elsewhere.

## 2.10. Connection to our methodology

| Literature finding | Supporting publication(s) | Implication for our project | Model / method implemented | Experiment |
|---|---|---|---|---|
| Tree ensembles are competitive for PM2.5 forecasting | Fetahi et al. (2025); Chivukula et al. (2026); Bhatta et al. (2026); Haseeb et al. (2026) | Include bagging and boosting | Random Forest, XGBoost | E1 |
| SVR can be the most consistent model at a 1-day horizon | Psomadakis et al. (2026); Abuouelezz et al. (2025) | Include a kernel model with scaling | SVR (RBF) + StandardScaler | E1 |
| Linear models are strong, interpretable references | Agibayeva et al. (2022); Hyso & Gjylapi (2026) | Include a regularized linear model | Ridge + StandardScaler | E1, E6 |
| Lag and rolling features dominate importance | Bhatta et al. (2026); Sapakova et al. (2026); Psomadakis et al. (2026) | Engineer lags, rolling means/SD/min/max, trend | Feature sets *basic → lag → full* | E2, E6 |
| Redundant correlated features are common | Agibayeva et al. (2022); Haseeb et al. (2026) | Compare complete and selected feature sets | Variance + correlation filter + top-k (train only) | E3 |
| Persistence can beat ML, especially at short horizons | Sapakova et al. (2026); Psomadakis et al. (2026); Hyso & Gjylapi (2026) | Benchmark against persistence on identical dates | Trailing 24-h mean persistence | E1, RQ3 |
| Temporal validation matters; random splits inflate results | Psomadakis et al. (2026); Chivukula et al. (2026); Makhdoomi et al. (2025) | Year-based split, TimeSeriesSplit with gap | Train 2021–23 / validation 2024 / test 2025 | Methodology |
| Concurrent co-pollutants leak information | Makhdoomi et al. (2025); Haseeb et al. (2026) | Only information available at 18:00 on day d | Issue-time feature construction + leakage tests | Methodology, tests |
| Extremes are under- or over-estimated | Haseeb et al. (2026); Agibayeva et al. (2022) | Evaluate elevated days separately; keep extremes | Train-quantile and WHO thresholds | E5 |
| Seasonality / heating period drives PM2.5 | Agibayeva et al. (2022); Bhatta et al. (2026) | Seasonal and heating-period error analysis | Calendar and heating features | E7 |
| Hyperparameters affect results; fixed settings can be suboptimal | Hyso & Gjylapi (2026); Haseeb et al. (2026) | Compare default and tuned settings with bounded search | RandomizedSearchCV | E4 |
| API-based systems should separate data, model and interface | Sapakova et al. (2026); Jalali et al. (2025) | Modular backend, CLI now, GUI later | `air_quality` package + CLI | RO7 |
